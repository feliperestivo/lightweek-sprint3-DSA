# Documentação técnica - LightWeek Sprint 3

## 1. Objetivo

O LightWeek foi adaptado para funcionar como um pequeno sistema de gerenciamento de uma estação de recarga. Em vez de calcular apenas uma recarga, o programa permite cadastrar várias sessões, manter os objetos em uma lista, pesquisar por ID, ordenar os registros e calcular estatísticas.

O programa foi desenvolvido em Python e funciona pelo terminal. As operações foram separadas em funções para o código ficar mais organizado e mais simples de entender.

## 2. Estrutura utilizada para uma sessão

Cada sessão é representada por um objeto da classe `Sessao`.

```python
class Sessao:
    def __init__(
        self,
        id_sessao,
        veiculo,
        tipo_carregador,
        energia_kwh,
        tempo_minutos,
        tarifa_kwh,
        data,
        status,
    ):
        self.id = id_sessao
        self.veiculo = veiculo
        self.tipo_carregador = tipo_carregador
        self.energia_kwh = energia_kwh
        self.tempo_minutos = tempo_minutos
        self.tarifa_kwh = tarifa_kwh
        self.data = data
        self.status = status
        self.custo = energia_kwh * tarifa_kwh
```

A classe foi escolhida porque todos os dados de uma sessão ficam reunidos no mesmo objeto. Isso evita trabalhar com várias listas separadas e deixa claro que ID, veículo, energia, tempo, tarifa e custo pertencem à mesma recarga.

O custo é calculado automaticamente pela fórmula:

```text
custo = energia consumida × tarifa por kWh
```

## 3. Armazenamento de múltiplas sessões

No início do programa é criada uma lista vazia:

```python
sessoes = []
```

Depois do cadastro e das validações, o novo objeto é colocado na lista:

```python
sessoes.append(nova_sessao)
```

O tamanho da lista informa quantas sessões estão armazenadas. Os mesmos objetos são utilizados pela listagem, busca, ordenação e pelas estatísticas.

## 4. Funcionamento geral

O programa utiliza um laço `while True` para manter o menu aberto. Cada opção chama uma função diferente:

| Opção | Função principal | Resultado |
| --- | --- | --- |
| Nova sessão | `cadastrar_sessao()` | Valida os dados, cria o objeto e adiciona na lista. |
| Listar | `listar_sessoes()` | Mostra os registros em uma tabela no terminal. |
| Buscar | `buscar_sessao()` | Solicita um ID e utiliza a busca sequencial. |
| Ordenar | `ordenar_sessoes()` | Escolhe o critério e executa o Insertion Sort. |
| Estatísticas | `mostrar_estatisticas()` | Exibe totais, média, maior e menor consumo. |
| Encerrar | `executar_programa()` | Finaliza o laço e fecha o programa. |

## 5. Validações

As entradas numéricas utilizam `try` e `except` para impedir que letras ou símbolos fechem o programa. Também foram adicionadas regras para:

- não permitir IDs menores que 1;
- não permitir ID repetido;
- não aceitar identificação de veículo vazia;
- impedir energia, tempo e tarifa negativos;
- limitar opções aos valores mostrados em cada menu;
- aceitar ponto ou vírgula nos números decimais;
- encerrar de maneira controlada com `Ctrl + C`.

O custo não é digitado pelo usuário. Ele é calculado a partir da energia e da tarifa, por isso não existe a possibilidade de cadastrar um custo negativo quando os dois valores foram validados.

## 6. Algoritmo de busca

Foi implementada a **Busca Sequencial**. Ela percorre a lista desde a primeira posição e compara o ID de cada objeto com o ID procurado.

```python
def busca_sequencial(sessoes, id_procurado):
    for indice in range(len(sessoes)):
        if sessoes[indice].id == id_procurado:
            return indice

    return -1
```

Quando a sessão é encontrada, a função retorna a posição. Caso percorra a lista inteira sem encontrar, retorna `-1`.

### Complexidade da busca

- **Melhor caso: O(1)** - o ID está logo na primeira posição.
- **Pior caso: O(n)** - o ID está na última posição ou não existe.
- **Caso médio: O(n)** - normalmente será necessário verificar uma parte da lista proporcional ao número de sessões.

O crescimento vem deste laço:

```python
for indice in range(len(sessoes)):
```

Se a quantidade de sessões dobrar, o número máximo de comparações também praticamente dobra. A vantagem é que a busca funciona mesmo quando a lista não está ordenada.

## 7. Algoritmo de ordenação

Foi implementado manualmente o **Insertion Sort**. O algoritmo considera que a parte inicial da lista já está organizada. Ele guarda o item atual, compara com os anteriores e desloca os objetos até encontrar a posição correta.

Trecho principal utilizado:

```python
for i in range(1, len(sessoes)):
    sessao_atual = sessoes[i]
    valor_atual = obter_valor_criterio(sessao_atual, criterio)
    j = i - 1

    while j >= 0:
        valor_anterior = obter_valor_criterio(sessoes[j], criterio)
        # comparação de acordo com a direção escolhida
        sessoes[j + 1] = sessoes[j]
        j -= 1

    sessoes[j + 1] = sessao_atual
```

O usuário pode ordenar em ordem crescente ou decrescente por:

1. ID;
2. energia consumida;
3. custo;
4. tempo de recarga.

Nenhum método pronto de ordenação substitui o algoritmo manual.

### Complexidade da ordenação

- **Melhor caso: O(n)** - a lista já está na ordem escolhida e o `while` quase não realiza deslocamentos.
- **Pior caso: O(n²)** - a lista está na ordem contrária e cada item precisa ser comparado com quase todos os anteriores.
- **Caso médio: O(n²)** - ainda existe uma quantidade quadrática de comparações e deslocamentos.

A complexidade quadrática aparece porque o `for` pode executar `n` vezes e, dentro dele, o `while` também pode voltar por quase `n` posições.

## 8. Comparação prática entre os algoritmos

| Algoritmo | Pior caso | Significado prático |
| --- | --- | --- |
| Busca Sequencial | O(n) | Com o dobro de sessões, o máximo de verificações cresce aproximadamente duas vezes. |
| Insertion Sort | O(n²) | Com o dobro de sessões, a quantidade de operações pode chegar perto de quatro vezes. |

Para uma atividade com poucas sessões, os dois algoritmos funcionam bem e são fáceis de acompanhar. Em uma estação real com milhares de registros, o Insertion Sort começaria a ficar lento mais rapidamente. Nesse caso, seria necessário estudar algoritmos mais eficientes e outras estruturas de dados.

## 9. Estatísticas

A função `calcular_estatisticas()` percorre os registros e calcula:

- quantidade total de sessões;
- energia total fornecida;
- faturamento total;
- custo médio;
- maior consumo;
- menor consumo.

Os valores são calculados somente com os objetos presentes na lista. A função faz uma passagem pelos dados, então sua complexidade é **O(n)**.

## 10. Conclusão

A evolução do LightWeek mostra como uma estrutura de dados permite organizar várias sessões dentro do mesmo sistema. A classe representa cada recarga, a lista armazena os objetos e os algoritmos permitem pesquisar e ordenar os registros. A análise Big-O ajuda a entender que duas soluções podem funcionar corretamente, mas apresentar comportamentos diferentes quando a quantidade de dados aumenta.
